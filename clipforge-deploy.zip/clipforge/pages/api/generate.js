/**
 * ClipForge — Secure API proxy for Anthropic
 * - API key stays server-side only
 * - IP-based rate limiting
 * - Input validation & sanitisation
 */

// Simple in-memory rate limiter (resets on serverless cold start — good enough for most use-cases)
// For production at scale, replace with Redis (e.g. Upstash)
const rateLimitMap = new Map();

function checkRateLimit(ip) {
  const limit = parseInt(process.env.RATE_LIMIT_PER_HOUR || "10", 10);
  const now = Date.now();
  const windowMs = 60 * 60 * 1000; // 1 hour

  const record = rateLimitMap.get(ip) || { count: 0, resetAt: now + windowMs };

  if (now > record.resetAt) {
    record.count = 0;
    record.resetAt = now + windowMs;
  }

  record.count += 1;
  rateLimitMap.set(ip, record);

  return {
    allowed: record.count <= limit,
    remaining: Math.max(0, limit - record.count),
    resetAt: record.resetAt,
  };
}

function buildPrompt({ platform, genre, tones, duration, topic, audience, extras }) {
  return `You are a world-class content strategist and video scriptwriter specialising in viral social media content.

Create a complete, detailed video concept for:
- Platform: ${platform}
- Genre: ${genre}
- Tone: ${Array.isArray(tones) ? tones.join(", ") : tones}
- Duration: ${duration}
- Topic: ${topic}
${audience ? `- Target Audience: ${audience}` : ""}
${extras ? `- Special Requirements: ${extras}` : ""}

Provide ALL of the following sections with detailed, actionable content:

**Video Title**: A compelling, click-worthy title optimised for the platform

**Hook**: An attention-grabbing opening (first 3–5 seconds) that hooks viewers immediately

**Outline**: A structured breakdown of the video's content with timestamps appropriate for the duration

**Script**: A detailed sample script covering the key sections of the video with natural, conversational dialogue

**Thumbnail Concept**: A vivid description of the ideal thumbnail — what text, imagery, colours, and composition to use

**Caption**: A complete ${platform === "YouTube" ? "YouTube description with chapters" : platform === "Instagram" ? "Instagram caption with line breaks" : "description/caption"} optimised for the platform

**Hashtags**: 12–15 relevant hashtags

**Music**: Recommended background music style/mood and specific royalty-free suggestions

**Tips**: 3 professional production tips specifically for this video

Be specific, creative, and platform-aware. Make every section genuinely useful and ready to use.`;
}

export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  // Check API key is configured
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error("ANTHROPIC_API_KEY not set");
    return res.status(500).json({ error: "Server configuration error: API key not set." });
  }

  // Rate limiting
  const ip =
    req.headers["x-forwarded-for"]?.split(",")[0]?.trim() ||
    req.socket?.remoteAddress ||
    "unknown";

  const { allowed, remaining, resetAt } = checkRateLimit(ip);
  res.setHeader("X-RateLimit-Remaining", remaining);

  if (!allowed) {
    const retryAfter = Math.ceil((resetAt - Date.now()) / 1000);
    res.setHeader("Retry-After", retryAfter);
    return res.status(429).json({
      error: `Rate limit reached. You can generate ${process.env.RATE_LIMIT_PER_HOUR || 10} videos per hour. Try again in ${Math.ceil(retryAfter / 60)} minutes.`,
    });
  }

  // Parse & validate body
  const { platform, genre, tones, duration, topic, audience, extras } = req.body || {};

  if (!topic || typeof topic !== "string" || topic.trim().length < 3) {
    return res.status(400).json({ error: "A video topic of at least 3 characters is required." });
  }
  if (topic.length > 300) {
    return res.status(400).json({ error: "Topic is too long (max 300 characters)." });
  }

  const safePlatform = ["YouTube", "Instagram", "Both"].includes(platform) ? platform : "YouTube";
  const safeGenre = typeof genre === "string" ? genre.slice(0, 50) : "Tutorial";
  const safeTones = Array.isArray(tones) ? tones.slice(0, 5).map(t => String(t).slice(0, 30)) : ["Energetic"];
  const safeDuration = typeof duration === "string" ? duration.slice(0, 30) : "5–7 min";
  const safeAudience = typeof audience === "string" ? audience.slice(0, 200) : "";
  const safeExtras = typeof extras === "string" ? extras.slice(0, 400) : "";

  // Call Anthropic
  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 2000,
        messages: [
          {
            role: "user",
            content: buildPrompt({
              platform: safePlatform,
              genre: safeGenre,
              tones: safeTones,
              duration: safeDuration,
              topic: topic.trim(),
              audience: safeAudience,
              extras: safeExtras,
            }),
          },
        ],
      }),
    });

    if (!anthropicRes.ok) {
      const errBody = await anthropicRes.json().catch(() => ({}));
      console.error("Anthropic error:", errBody);
      return res.status(502).json({
        error: errBody?.error?.message || "Upstream API error. Please try again.",
      });
    }

    const data = await anthropicRes.json();
    const text = data.content?.map(c => c.text || "").join("\n") || "";

    return res.status(200).json({ result: text });
  } catch (err) {
    console.error("Generate error:", err);
    return res.status(500).json({ error: "Internal server error. Please try again." });
  }
}
