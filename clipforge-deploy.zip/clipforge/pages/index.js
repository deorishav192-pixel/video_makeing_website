import Head from 'next/head';
import { useState, useCallback } from 'react';
import styles from '../styles/Home.module.css';

// ─── Constants ────────────────────────────────────────────────────────────────

const GENRES = [
  'Vlog', 'Tutorial', 'Review', 'Short Film', 'Documentary',
  'Comedy', 'Educational', 'Fitness', 'Cooking', 'Travel',
  'Tech', 'Fashion', 'Gaming', 'Motivation', 'Interview',
];

const TONES = [
  'Energetic', 'Calm', 'Humorous', 'Inspirational', 'Dramatic',
  'Professional', 'Casual', 'Mysterious', 'Heartwarming', 'Edgy',
];

const DURATIONS = {
  YouTube:   ['1–3 min', '5–7 min', '10–15 min', '20+ min'],
  Instagram: ['15 sec',  '30 sec',  '60 sec',    '3–5 min'],
  Both:      ['30 sec',  '1–3 min', '5–7 min',   '10+ min'],
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function parseResult(raw) {
  const get = (key) => {
    const re = new RegExp(
      `\\*?\\*?${key}\\*?\\*?:?\\s*([\\s\\S]*?)(?=\\*?\\*?(?:Video Title|Hook|Script|Outline|Thumbnail|Hashtag|SEO|Call|Tips|Format|Music|Caption|$))`,
      'i'
    );
    const m = raw.match(re);
    return m ? m[1].trim() : '';
  };

  const titleMatch = raw.match(/\*?\*?(?:Video )?Title\*?\*?:?\s*["\u201c]?([^\n""\u201d]+)["\u201d]?/i);
  const title = titleMatch ? titleMatch[1].trim() : 'Your Video Concept';

  const hook      = get('Hook');
  const outline   = get('Outline|Structure|Sections');
  const script    = get('Script|Full Script|Sample Script');
  const thumbnail = get('Thumbnail(?:\\s+Concept)?(?:\\s+Idea)?');
  const hashtags  = get('Hashtag|Tags|Keywords');
  const tips      = get('Tips|Pro Tips|Production Tips');
  const caption   = get('Caption|Description|YouTube Description|Instagram Caption');
  const music     = get('Music(?:\\s+Direction)?(?:\\s+Background)?');

  const htags = [...(raw + ' ' + hashtags).matchAll(/#[\w]+/g)]
    .map(m => m[0])
    .filter((v, i, a) => a.indexOf(v) === i)
    .slice(0, 15);

  return { title, hook, outline, script, thumbnail, hashtags: htags, tips, caption, music, raw };
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SectionBlock({ label, children }) {
  if (!children) return null;
  return (
    <div className={styles.sectionBlock}>
      <h3 className={styles.sectionLabel}><span />{label}</h3>
      {children}
    </div>
  );
}

function OutlineList({ text }) {
  const lines = text.split('\n').map(l => l.replace(/^[\d.\-*]+\s*/, '').trim()).filter(Boolean);
  if (!lines.length) return <p className={styles.prose}>{text}</p>;
  return (
    <div className={styles.outlineList}>
      {lines.map((line, i) => (
        <div key={i} className={styles.outlineLine}>
          <span className={styles.outlineNum}>{String(i + 1).padStart(2, '0')}</span>
          <span className={styles.prose}>{line}</span>
        </div>
      ))}
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────

export default function Home() {
  // Form state
  const [platform, setPlatform] = useState('YouTube');
  const [genre, setGenre]       = useState('Tutorial');
  const [tones, setTones]       = useState(['Energetic']);
  const [duration, setDuration] = useState('');
  const [topic, setTopic]       = useState('');
  const [audience, setAudience] = useState('');
  const [extras, setExtras]     = useState('');

  // UI state
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [result, setResult]     = useState(null);
  const [copied, setCopied]     = useState(false);

  const durs = DURATIONS[platform];

  const toggleTone = useCallback((t) => {
    setTones(prev => prev.includes(t) ? prev.filter(x => x !== t) : [...prev, t]);
  }, []);

  const handlePlatformChange = (p) => {
    setPlatform(p);
    setDuration('');
  };

  const generate = async () => {
    if (!topic.trim()) { setError('Please enter a video topic.'); return; }
    if (topic.trim().length < 3) { setError('Topic must be at least 3 characters.'); return; }
    setError('');
    setLoading(true);
    setResult(null);

    const selectedDuration = duration || durs[0];

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform,
          genre,
          tones,
          duration: selectedDuration,
          topic: topic.trim(),
          audience: audience.trim(),
          extras: extras.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        setError(data.error || 'Something went wrong. Please try again.');
      } else {
        setResult(parseResult(data.result));
      }
    } catch (err) {
      setError('Network error — please check your connection and try again.');
    } finally {
      setLoading(false);
    }
  };

  const copyAll = () => {
    if (!result) return;
    navigator.clipboard.writeText(result.raw).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const platformTag =
    platform === 'YouTube' ? styles.tagYt :
    platform === 'Instagram' ? styles.tagIg :
    styles.tagBoth;

  return (
    <>
      <Head>
        <title>ClipForge — AI Video Studio</title>
      </Head>

      {/* Background effects */}
      <div className={styles.noise} aria-hidden />
      <div className={`${styles.orb} ${styles.orb1}`} aria-hidden />
      <div className={`${styles.orb} ${styles.orb2}`} aria-hidden />

      <div className={styles.app}>

        {/* ── Header ── */}
        <header className={styles.header}>
          <div className={styles.logo}>CLIP<span>FORGE</span></div>
          <div className={styles.badge}>AI Video Studio</div>
        </header>

        {/* ── Hero ── */}
        <section className={styles.hero}>
          <p className={styles.eyebrow}>Powered by Claude AI</p>
          <h1>Generate <em>Viral</em><br />Video Concepts</h1>
          <p className={styles.heroSub}>
            Instantly craft complete scripts, outlines, thumbnails, and hashtag strategies —
            built for YouTube &amp; Instagram.
          </p>
        </section>

        {/* ── Main grid ── */}
        <div className={styles.main}>

          {/* ── Sidebar ── */}
          <aside className={styles.sidebar}>

            {/* Platform */}
            <div className={styles.fieldGroup}>
              <p className={styles.groupLabel}>Platform</p>
              <div className={styles.platformGrid}>
                {['YouTube', 'Instagram', 'Both'].map(p => (
                  <button
                    key={p}
                    className={`${styles.platformBtn} ${platform === p ? styles.platformActive : ''}`}
                    onClick={() => handlePlatformChange(p)}
                    style={p === 'Both' ? { gridColumn: '1/-1' } : {}}
                    type="button"
                  >
                    <span className={styles.platformIcon}>
                      {p === 'YouTube' ? '▶' : p === 'Instagram' ? '◈' : '⬡'}
                    </span>
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Content */}
            <div className={styles.fieldGroup}>
              <p className={styles.groupLabel}>Content</p>

              <div className={styles.field}>
                <label htmlFor="topic">Topic <span className={styles.required}>*</span></label>
                <input
                  id="topic"
                  type="text"
                  placeholder="e.g. Morning routine for productivity"
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && generate()}
                  maxLength={300}
                  autoComplete="off"
                />
              </div>

              <div className={styles.field}>
                <label htmlFor="genre">Genre</label>
                <select id="genre" value={genre} onChange={e => setGenre(e.target.value)}>
                  {GENRES.map(g => <option key={g}>{g}</option>)}
                </select>
              </div>

              <div className={styles.field}>
                <label htmlFor="audience">Target Audience <span className={styles.optional}>(optional)</span></label>
                <input
                  id="audience"
                  type="text"
                  placeholder="e.g. Busy professionals aged 25–40"
                  value={audience}
                  onChange={e => setAudience(e.target.value)}
                  maxLength={200}
                />
              </div>
            </div>

            {/* Style */}
            <div className={styles.fieldGroup}>
              <p className={styles.groupLabel}>Style</p>

              <div className={styles.field}>
                <label>Tone <span className={styles.optional}>(pick any)</span></label>
                <div className={styles.chipGroup}>
                  {TONES.map(t => (
                    <button
                      key={t}
                      type="button"
                      className={`${styles.chip} ${tones.includes(t) ? styles.chipActive : ''}`}
                      onClick={() => toggleTone(t)}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div className={styles.field}>
                <label>Duration</label>
                <div className={styles.durGrid}>
                  {durs.map(d => (
                    <button
                      key={d}
                      type="button"
                      className={`${styles.durBtn} ${duration === d ? styles.durActive : ''}`}
                      onClick={() => setDuration(d)}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              <div className={styles.field}>
                <label htmlFor="extras">Special Notes <span className={styles.optional}>(optional)</span></label>
                <textarea
                  id="extras"
                  placeholder="e.g. Include a product review, must end with a CTA…"
                  value={extras}
                  onChange={e => setExtras(e.target.value)}
                  maxLength={400}
                  rows={3}
                />
              </div>
            </div>

            <button
              className={styles.generateBtn}
              onClick={generate}
              disabled={loading}
              type="button"
            >
              {loading
                ? <><span className={styles.shimmer} /><span>GENERATING…</span></>
                : 'GENERATE VIDEO'
              }
            </button>

            {error && <div className={styles.errorBox} role="alert">{error}</div>}
          </aside>

          {/* ── Output pane ── */}
          <main className={styles.output}>

            {/* Empty state */}
            {!loading && !result && (
              <div className={styles.emptyState}>
                <div className={styles.emptyIcon}>🎬</div>
                <h2>Your Video Awaits</h2>
                <p>Fill in your preferences and hit Generate<br />to create a complete, ready-to-shoot video concept.</p>
              </div>
            )}

            {/* Loading */}
            {loading && (
              <div className={styles.loadingState} aria-live="polite">
                <div className={styles.spinner} />
                <p className={styles.loadingTitle}>Crafting Your Vision</p>
                <p className={styles.loadingSubtitle}>Building script, outline, thumbnail &amp; more…</p>
              </div>
            )}

            {/* Result */}
            {result && !loading && (
              <div>
                <div className={styles.regenRow}>
                  <button className={styles.regenBtn} onClick={generate} type="button">↺ Regenerate</button>
                  <span className={styles.regenHint}>Results are AI-generated — refine as needed</span>
                </div>

                <article className={styles.resultCard}>

                  {/* Card header */}
                  <div className={styles.resultHeader}>
                    <div className={styles.resultHeaderInner}>
                      <div className={styles.tagRow}>
                        <span className={`${styles.tag} ${platformTag}`}>{platform}</span>
                        <span className={`${styles.tag} ${styles.tagGenre}`}>{genre}</span>
                        <span className={`${styles.tag} ${styles.tagDur}`}>{duration || durs[0]}</span>
                        {tones.slice(0, 2).map(t => (
                          <span key={t} className={`${styles.tag} ${styles.tagTone}`}>{t}</span>
                        ))}
                      </div>
                      <h2 className={styles.resultTitle}>{result.title}</h2>
                    </div>
                    <button className={styles.copyBtn} onClick={copyAll} type="button">
                      {copied ? '✓ Copied!' : 'Copy All'}
                    </button>
                  </div>

                  {/* Card body */}
                  <div className={styles.resultBody}>

                    <SectionBlock label="Hook — First 3–5 Seconds">
                      <p className={styles.prose}>{result.hook}</p>
                    </SectionBlock>

                    <SectionBlock label="Video Outline">
                      <OutlineList text={result.outline} />
                    </SectionBlock>

                    <SectionBlock label="Sample Script">
                      <pre className={styles.scriptBox}>{result.script}</pre>
                    </SectionBlock>

                    <SectionBlock label="Thumbnail Concept">
                      {/* Visual mock */}
                      <div className={styles.thumbMock}>
                        <span className={styles.thumbLabel}>THUMBNAIL PREVIEW</span>
                        <div>
                          <p className={styles.thumbTitle}>{result.title.toUpperCase()}</p>
                          <p className={styles.thumbSub}>{(result.thumbnail || '').slice(0, 90)}</p>
                        </div>
                      </div>
                      <p className={styles.prose} style={{ marginTop: '12px' }}>{result.thumbnail}</p>
                    </SectionBlock>

                    <SectionBlock label={platform === 'Instagram' ? 'Instagram Caption' : 'Video Description'}>
                      <pre className={styles.scriptBox}>{result.caption}</pre>
                    </SectionBlock>

                    <SectionBlock label="Music Direction">
                      <p className={styles.prose}>{result.music}</p>
                    </SectionBlock>

                    <SectionBlock label="Production Tips">
                      <p className={styles.prose}>{result.tips}</p>
                    </SectionBlock>

                    {result.hashtags.length > 0 && (
                      <SectionBlock label="Hashtags &amp; Tags">
                        <div className={styles.hashtagGrid}>
                          {result.hashtags.map((h, i) => (
                            <span key={i} className={styles.hashtag}>{h}</span>
                          ))}
                        </div>
                      </SectionBlock>
                    )}

                    {/* Actions */}
                    <div className={styles.actionsRow}>
                      <button className={`${styles.actionBtn} ${styles.actionPrimary}`} onClick={copyAll} type="button">
                        {copied ? '✓ Copied!' : '📋 Copy Full Concept'}
                      </button>
                      <button className={`${styles.actionBtn} ${styles.actionSecondary}`} onClick={generate} type="button">
                        ↺ Regenerate
                      </button>
                    </div>

                  </div>
                </article>
              </div>
            )}
          </main>
        </div>

        <footer className={styles.footer}>
          Built with ClipForge &nbsp;·&nbsp; Powered by Claude AI
        </footer>
      </div>
    </>
  );
}
